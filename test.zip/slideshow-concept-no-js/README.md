# Slideshow Concept (No JS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/pbutcher/pen/gKqKdv](https://codepen.io/pbutcher/pen/gKqKdv).

CSS and HTML Only Slideshow Concept